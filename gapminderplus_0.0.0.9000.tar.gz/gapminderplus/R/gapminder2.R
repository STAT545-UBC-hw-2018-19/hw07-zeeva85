#' gapminder2
#'
#'
#' @format object of class tibble inherited from class table and dataframe
#' @source gapminder package
"gapminder2"
