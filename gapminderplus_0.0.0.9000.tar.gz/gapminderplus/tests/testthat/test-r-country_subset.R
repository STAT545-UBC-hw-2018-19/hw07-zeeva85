context("test-r-country_subset")

test_that("multiplication works", {
  expect_equal(2 * 2, 4)
})
