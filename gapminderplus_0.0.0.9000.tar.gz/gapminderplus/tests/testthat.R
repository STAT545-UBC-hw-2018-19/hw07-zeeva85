library(testthat)
library(gapminderplus)

test_check("gapminderplus")
